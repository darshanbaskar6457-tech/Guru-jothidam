# Guru Jothidam Android

This project packages the supplied Guru Jothidam web app as a native Android WebView app.

## Build
1. Open this folder in Android Studio.
2. Allow Gradle to download the Android Gradle Plugin/dependencies.
3. Select **Build > Build APK(s)**.
4. The debug APK will be under `app/build/outputs/apk/debug/`.

App label: **Guru Jothidam**
Application ID: `com.gurujothidam.app`
